## Database
Database name:lab04_peter
Table 1 (parent):customers
Table 2 (child):orders
Primary key (Table 1):customer_id
Foreign key (Table 2):customer_id
## Data
Rows in Table 1: 1, Bill, Bob, bill.bob@gmail.com, 2026-02-03 03:32:08
                2, Jane, Bob, bob.jane@gmail.com, 2026-02-03 03:33:37
                3, John, Bob, johnbob@gmail.com, 2026-02-03 03:34:21
Rows in Table 2:1, 1, 2026-02-02, 52.99, Paid
                2, 2, 2026-02-02, 33.99, Pending
                3, 3, 2026-02-02, 13.50, Paid

## JOIN query I ran
```sql
SELECT c.customer_id, c.first_name,
c.last_name, c.email,
o.order_id, o.order_date,
o.total_amount, o.status
FROM customers c
JOIN orders o ON c.customer_id =
o.customer_id;
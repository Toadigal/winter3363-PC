<?php
declare(strict_types=1);
require_once __DIR__ . "/config.php";
function require_login(): void {
 if (empty($_SESSION["user_id"])) {
 header("Location: login.php");
 exit;
 }
}
function require_role(string $role): void {
 require_login();
 if (($_SESSION["role"] ?? "") !== $role) {
 http_response_code(403);
 echo "403 Forbidden";
 exit;
 }
}
function on_login_success(int $user_id, string $email, string $role): void {
// Prevent session fixation
 session_regenerate_id(true);
 $_SESSION["user_id"] = $user_id;
 $_SESSION["email"] = $email;
 $_SESSION["role"] = $role;
 // Used for inactivity timeout
 $_SESSION["last_activity"] = time();
}
function enforce_session_timeout(): void {
 if (!empty($_SESSION["user_id"])) {
 $last = $_SESSION["last_activity"] ?? time();
 // STUDENT TODO: Confirm your SESSION_TIMEOUT value in config.php.
 if ((time() - $last) > SESSION_TIMEOUT) {
 // Timeout -> logout
 $_SESSION = [];
 if (ini_get("session.use_cookies")) {
 $p = session_get_cookie_params();
 setcookie(session_name(), "", time() - 42000, $p["path"], $p["domain"],
$p["secure"], $p["httponly"]);
 }
 session_destroy();
 header("Location: login.php?timeout=1");
 exit;
 }
 // Update last activity
 $_SESSION["last_activity"] = time();
 }
}   
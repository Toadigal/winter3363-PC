# Lab 06 — PHP Web Security & Sessions (Secure Notes)
**Student Name:** ____Peter Cromwell__
**Date:** _____16-02-2026_____________
## 1) What I built (1–2 sentences)
___What I built was a note taking website with working login/out features, security checks and registration page.
____________________________________________________________________
## 2) How to run my lab
**Database name:** `lab06_peter
**Start page URL:**http://localhost/winter3363/lab06/public/index.php
Steps:
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin and create my database
3. Run the Lab06 SQL to create tables: `users`, `notes`
4. Update `app/db.php` with my DB name
5. Open the start page URL above
## 3) Security features checklist:
## 4) Test Results (PASS/FAIL)
- Register works: ___PASS_
- Login works (correct password): ____PASS
- Login fails (wrong password): ___PASS_
- Dashboard redirects when logged out: ___PASS_
- Create note works: ___PASS_
- XSS test does NOT run (`<script>alert('xss')</script>`): __PASS _
- Admin page (user gets 403): __PASS _
- Admin page (admin can view): ___PASS_
- Session timeout works: __PASS _
## 5) Reflection: what I have learned from Lab 06 (3-5 sentences)
I learned alot about the need of proper security features in user interfaces like password hashing and user/admin roles and access. It has informed me as well about protected pages and their role in web design. This assignment has given me lots of useful tips to introduce into my own personal projects and works going forward. 
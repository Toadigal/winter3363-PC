Lab 03 - PHP Forms + Validation

This project is meant to demostrate how to use various coding skills to make a working login/out page. Further more it shows about server-side validation. 

FEATURES:
1. Validation
2. Sessions
3. Protected Page
4. Login/out 

Setup instructions:
1. Open the XAMPP and start Apache.
2. Then you'll want to ensure under xampp in your file folder follows this path. The drive depends on where you installed XAMPP so for example it should be: D:\xampp\htdocs\winter3363\lab03\
3. From there you should be ready to edit/change any information you need to adjust it to your information (name, titles, etc.) in VsCode or other software of the like. And you can now move onto testing your site locally using XAMPP and your web browser. 

How to Test:
1. Add this to your browser. (ensure matches your folder names if using your own copy you've adjusted) http://localhost/winter3363/lab03/. This should be working if you are taken to your login.php. 
2. On the login.php attempt to hit login using blank fields and it will be working properly if this returns a require field error.
3. Attempt to use incorrect login credentials and it should return a invalid login message if working correctly.
4. Use the correct credentials (i.e the demo credentials: user - student. password - Lab03!). This should take you to the dashboard saying "Welcome students" if working properly. 
5. Click the logout button and if its working properly it should return you to the login page and the session should have ended. 

<?php
header(header: "Location: login.php");
exit;
?>
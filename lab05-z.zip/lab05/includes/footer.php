<?php
?>
 <hr />
 <p class="muted">Lab 05 - PDO CRUD (XAMPP Localhost). Peter Cromwell 2026</p>
 </div>
</body>
</html>